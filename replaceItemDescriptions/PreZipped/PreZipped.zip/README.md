# Replace Consumable Item Descriptions

## Features
Adds the consumable effects as part of item description